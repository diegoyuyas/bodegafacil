/**
 * Bodega Fácil — Puertos de repositorio
 * ------------------------------------------------------------
 * La UI y la capa de negocio dependen de estas interfaces, nunca
 * de SQLite directamente (sección 5 del documento maestro: "la capa
 * de persistencia debe abstraerse de la interfaz"). La implementación
 * concreta vive en `src/infraestructura/sqlite/*` y se podría
 * reemplazar (ej. por el plugin nativo de Capacitor) sin tocar la UI.
 */

import type {
  Cliente,
  Compra,
  LineaVentaResumen,
  MetodoPagoSinFiado,
  MovimientoCaja,
  Producto,
  Proveedor,
  RegistrarVentaInput,
  ResumenDia,
  Venta,
  VentaListaItem,
} from './tipos';
import type { FilaVentaDetallada } from './exportacion';
import type { EstadoPlan } from './plan';

export interface ProductoRepositorio {
  listarActivos(): Producto[];
  /** Para la pantalla de administración: incluye también los inactivos. */
  listarTodos(): Producto[];
  buscarPorNombre(texto: string): Producto[];
  obtenerPorId(id: number): Producto;
  crear(datos: DatosNuevoProducto): Producto;
  actualizarStock(id: number, nuevoStock: number): void;
  /** Edita los datos del producto, incluyendo si está activo (los inactivos no salen a vender). */
  actualizar(id: number, datos: DatosActualizarProducto): Producto;
}

export interface DatosNuevoProducto {
  nombre: string;
  categoriaId?: number | null;
  codigo?: string | null;
  precioVenta: number;
  costo: number;
  stockActual: number;
  stockMinimo: number;
  unidadMedida: string;
}

export interface DatosActualizarProducto {
  nombre: string;
  categoriaId?: number | null;
  codigo?: string | null;
  precioVenta: number;
  costo: number;
  stockMinimo: number;
  unidadMedida: string;
  activo: boolean;
}

export interface ClienteRepositorio {
  listarActivos(): Cliente[];
  /** Para la pantalla de administración: incluye también los inactivos. */
  listarTodos(): Cliente[];
  buscarPorTexto(texto: string): Cliente[];
  obtenerPorId(id: number): Cliente;
  crear(nombre: string, documento: string, telefono?: string | null): Cliente;
  /** Edita los datos del cliente, incluyendo si está activo. */
  actualizar(id: number, datos: DatosActualizarCliente): Cliente;
}

export interface DatosActualizarCliente {
  nombre: string;
  documento: string;
  telefono?: string | null;
  activo: boolean;
}

export interface VentaRepositorio {
  registrarVenta(input: RegistrarVentaInput): Venta;
  obtenerPorId(id: number): Venta;
  listarDeHoy(): Venta[];
  /** Para Inicio: ventas de hoy con nombre de cliente ya resuelto. */
  listarDeHoyConDetalle(): VentaListaItem[];
  /** Para el preview al expandir una venta en la lista. */
  obtenerLineas(ventaId: number): LineaVentaResumen[];
  /** Repone stock, revierte caja/deuda, y marca la venta como anulada. */
  anularVenta(id: number, motivo?: string): void;
  resumenDelDia(fechaIso?: string): ResumenDia;
  /** Total histórico de ventas válidas (no anuladas) — para el umbral de Plan Pro. */
  contarTotalHistorico(): number;
  /**
   * Filas planas (venta + producto + cliente) listas para exportar a CSV.
   * `desde`/`hasta` son fechas 'YYYY-MM-DD' inclusivas; sin ellas, exporta todo el historial.
   */
  listarDetalleParaExportar(desde?: string, hasta?: string): FilaVentaDetallada[];
}

/**
 * La caja es su propio dominio: tanto una venta al contado como el pago
 * de una deuda generan un ingreso de caja. Separarlo evita duplicar la
 * lógica de "saldo anterior + ingresos - egresos" en cada repositorio.
 */
export interface CajaRepositorio {
  obtenerSaldoActual(): number;
  registrarIngreso(
    monto: number,
    concepto: string,
    metodoPago: MetodoPagoSinFiado,
    ventaId?: number | null,
  ): void;
  registrarEgreso(monto: number, concepto: string, metodoPago: MetodoPagoSinFiado): void;
  listarMovimientosDeHoy(): MovimientoCaja[];
}

export interface FiadoRepositorio {
  /**
   * Sin `desde`/`hasta`: todos los clientes con deuda activa hoy (para
   * la pantalla de Fiados). Con el rango 'YYYY-MM-DD' inclusive: solo
   * los clientes que generaron algún fiado dentro de ese período (para
   * exportar), aunque el saldo mostrado siempre es el saldo actual.
   */
  listarClientesConDeuda(desde?: string, hasta?: string): Cliente[];
  registrarPago(clienteId: number, monto: number, metodoPago: MetodoPagoSinFiado): void;
}

export interface ProveedorRepositorio {
  listarActivos(): Proveedor[];
  /** Para la pantalla de administración: incluye también los inactivos. */
  listarTodos(): Proveedor[];
  buscarPorTexto(texto: string): Proveedor[];
  obtenerPorId(id: number): Proveedor;
  crear(nombre: string, ruc?: string | null, telefono?: string | null): Proveedor;
  /** Edita los datos del proveedor, incluyendo si está activo. */
  actualizar(id: number, datos: DatosActualizarProveedor): Proveedor;
}

export interface DatosActualizarProveedor {
  nombre: string;
  ruc?: string | null;
  telefono?: string | null;
  activo: boolean;
}

export interface LineaCompraEntrada {
  productoId: number;
  cantidad: number;
  costoUnitario: number;
}

export interface RegistrarCompraInput {
  proveedorId?: number | null;
  /** Nombre escrito al vuelo, usado solo si no se eligió proveedorId. */
  proveedorNombreLibre?: string | null;
  /** Serie-número del comprobante, libre, hasta 15 caracteres. */
  comprobante?: string | null;
  lineas: LineaCompraEntrada[];
  metodoPago: MetodoPagoSinFiado;
}

export interface CompraRepositorio {
  /**
   * Registra una compra ya recibida: entra stock, se actualiza el
   * costo del producto (para que la ganancia futura sea correcta), y
   * sale el dinero de caja. En el Plan Gratis se asume que la compra
   * se paga al recibirla — sin cuentas por pagar pendientes.
   */
  registrarCompra(input: RegistrarCompraInput): Compra;
  listarRecientes(limite?: number): Compra[];
}

/** Acceso crudo clave-valor a la tabla configuracion_app. */
export interface ConfiguracionRepositorio {
  obtenerValor(clave: string): string | null;
  establecerValor(clave: string, valor: string): void;
  eliminarValor(clave: string): void;
}

/**
 * Panel de administrador: activar/desactivar Premium y proteger todo
 * eso con un PIN que solo conoce el dueño de la app (nunca se guarda
 * en texto plano, solo su hash).
 */
export interface PlanRepositorio {
  obtenerEstado(): EstadoPlan;
  /** `dias` puede ser cualquiera de los presets o un número libre entre 1 y 365. */
  activarPremium(dias: number): void;
  desactivarPremium(): void;
  tienePinConfigurado(): boolean;
  configurarPin(pinNuevo: string): Promise<void>;
  verificarPin(pin: string): Promise<boolean>;
  /** Devuelve false (sin cambiar nada) si pinActual no es correcto. */
  cambiarPin(pinActual: string, pinNuevo: string): Promise<boolean>;
}
